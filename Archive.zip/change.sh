rm .DS_Store
git add .
git commit -m "something"
git push
